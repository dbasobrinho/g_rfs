select version_no from apex_release
/
