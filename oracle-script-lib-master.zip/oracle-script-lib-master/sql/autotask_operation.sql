
@@autotask_sql_setup

select 
	client_name
		, operation_name
		, operation_tag
		, priority_override
		, attributes
		, use_resource_estimates
		, status
from DBA_AUTOTASK_OPERATION
/
