REM $Header: sqdefparams.sql 11.4.5.0 2012/11/21 carlos.sierra $

DEF connect_identifier      = '';
DEF enter_tool_password     = 'sqltxplain';
DEF re_enter_password       = 'sqltxplain';
DEF default_tablespace      = 'USERS';
DEF temporary_tablespace    = 'TEMP';
DEF main_application_schema = '';
DEF pack_license            = 'T';
