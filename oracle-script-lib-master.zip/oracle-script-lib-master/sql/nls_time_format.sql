
alter session set nls_timestamp_format='yyyy-mm-dd hh24:mi:ssxff';
alter session set nls_date_format='yyyy-mm-dd hh24:mi';

