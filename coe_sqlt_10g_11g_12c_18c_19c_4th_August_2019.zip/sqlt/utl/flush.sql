REM Flushes the shared pool. Just execute "@flush.sql" from sqlplus.
ALTER SYSTEM FLUSH SHARED_POOL;
