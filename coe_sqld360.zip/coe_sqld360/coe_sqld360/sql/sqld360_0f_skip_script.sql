PRO Skip script &1. as per execution parameter
