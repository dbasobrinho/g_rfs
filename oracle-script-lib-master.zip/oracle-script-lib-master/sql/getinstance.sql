
col uinstance new_value uinstance noprint

-- set term and feed off then back on when calling

select instance_name uinstance
from v$instance
/


