PRO
PRO <br>
PRO <font class="f">&&sqld360_prefix.&&sqld360_copyright.. Version &&sqld360_vrsn.. Report executed on &&sqld360_time_stamp. for SQL ID &&sqld360_sqlid. (&&sqld360_sqltxt) </font>
PRO </body>
PRO </html>
