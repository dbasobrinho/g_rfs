#!/bin/bash
# Fred Denis -- Sept 3rd 2019
#
# Show GG status
#


GGSCI=ggsci

cd $GGHOME

echo "info all" | ggsci

#************************************************************************#
#                       E N D      O F      S O U R C E                 *#
#************************************************************************#
