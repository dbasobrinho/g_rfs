PROMPT XDB / EM Express port:
SELECT dbms_xdb_config.getHTTPport HTTP, dbms_xdb_config.getHTTPSport HTTPS FROM dual;

