alter system enable restricted session; 
