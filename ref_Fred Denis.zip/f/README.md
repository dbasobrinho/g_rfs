# oracle-scripts
https://unknowndba.blogspot.com/
