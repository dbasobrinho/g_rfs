
new things to add to master

don't forget to document

